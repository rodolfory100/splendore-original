# Varredura Sênior — Splendore Sistema

## BUGS CRÍTICOS (quebram funcionalidade)

### BUG-1 ✅ CORRIGIR: Rota /alertas → 404
- Frontend: `getAlertas()` → `/alertas`, `addAlerta()` → `/alertas`, `resolverAlerta()` → `/alertas/:id/resolver`
- Backend: só existe `/sistema/alertas`, `/sistema/alertas`, `/sistema/alertas/:id/resolver`
- **Fix:** Adicionar aliases no backend OU corrigir frontend

### BUG-2 ✅ CORRIGIR: Rota /contratos/aluna/:id → 404
- Frontend: `getContratosByAluna(id)` → `/contratos/aluna/${id}`
- Backend: só existe `GET /contratos/:alunaId`
- **Fix:** Corrigir frontend para `/contratos/${alunaId}`

### BUG-3 ✅ CORRIGIR: Rota /financeiro/dre → 404
- Frontend: `getDRE(mes)` → `/financeiro/dre?mes=YYYY-MM`
- Backend: `GET /financeiro/dre/:mes` (parâmetro na URL, não query string)
- **Fix:** Corrigir backend para aceitar query param OU frontend para enviar na URL

### BUG-4 ✅ CORRIGIR: Turma não tem edição (PUT missing)
- Frontend TurmasPage não tem botão editar e não chama updateTurma
- Backend não tem `PUT /turmas/:id`
- **Fix:** Adicionar endpoint + botão de editar turma

### BUG-5 ✅ CORRIGIR: CobrancasPage faz GET /pagamentos inteiro (performance)
- `pagarRapido` faz `fetch('/api/pagamentos')` — traz TODOS os pagamentos do banco
- Com 500+ registros fica lento
- **Fix:** Usar dados já carregados de `/mensalidades/:id` (já é feito no primeiro passo, mas cai no else desnecessariamente)

### BUG-6 ✅ CORRIGIR: CobrancasPage não manda Authorization header
- `pagarRapido` usa `fetch()` puro sem token JWT — vai dar 401 em produção
- **Fix:** Substituir por `req()` da lib/api que injeta o token automaticamente

### BUG-7 ✅ CORRIGIR: MensalidadesPage — seleção checkboxes usa ID errado
- `pagId = m.pagamento?.id || m.mes` — quando não tem pagamento, usa `m.mes` como ID de seleção
- Mas ao editar lote, manda `mesIds` (IDs reais) OU `meses` (YYYY-MM) — isso causa confusão
- **Fix:** Padronizar — sempre usar `m.mes` como identificador de seleção, simplificar lógica do lote

### BUG-8 ✅ CORRIGIR: isPago no AlunosPage considera bolsista como inadimplente no visual
- `statInad = filtered.filter(a => !isPago(a.id) && !(a as any).bolsista)` — OK aqui
- Mas o card de cada aluna na listagem usa apenas `isPago(a.id)` sem verificar bolsista
- Bolsista aparece como "vermelho/inadimplente" na lista

## PROBLEMAS DE QUALIDADE (não quebram mas prejudicam)

### Q-1: JWT_SECRET hardcoded no código
- `const JWT_SECRET = 'splendore_jwt_secret_2026_producao'`
- Deveria vir de variável de ambiente. Mas em Workers, sem .env fácil, manter como está é aceitável.
- **Fix:** Documentar — não é urgente

### Q-2: `getPagamentos()` traz todos sem paginação
- Com 500+ registros, a Dashboard e PagamentosPage ficam lentas
- **Fix:** Limitar a 200 mais recentes + adicionar filtro por mês no endpoint

### Q-3: Renovacoes inclui alunas sem data de contrato como 'sem_contrato'
- Exibe todas as ativas sem contratoAte — polui a tela de renovações
- **Fix:** Filtrar somente as que têm contratoAte OU diasRestantes <= 90

### Q-4: TurmasPage sem edição
- Não tem botão editar turma, só criar e deletar

### Q-5: Mensalidades — ao deletar pagamento não limpa `pagamento` no state
- Após `PUT /pagamentos/:id/pagar`, o estado local não é atualizado imediatamente
- Já corrigido parcialmente com o delay de 500ms, mas poderia ser update otimista

## MELHORIAS RECOMENDADAS

### M-1: Adicionar confirmação de pagamento na CobrancasPage
- Ao clicar "Pago" mostrar modal com valor e forma antes de confirmar

### M-2: Limite de 200 pagamentos no GET /pagamentos
- Performance crítica com banco grande

### M-3: Renovacoes filtrar só com contrato
- Não mostrar alunas sem contratoAte

## STATUS
- [ ] BUG-1: Corrigir rotas alertas
- [ ] BUG-2: Corrigir rota contratos/aluna
- [ ] BUG-3: Corrigir rota financeiro/dre
- [ ] BUG-4: Adicionar PUT /turmas/:id + botão editar
- [ ] BUG-5+6: Refatorar pagarRapido (sem fetch global, com auth header)
- [ ] BUG-7: Padronizar seleção checkboxes mensalidades
- [ ] BUG-8: Corrigir badge de bolsista na lista de alunas
- [ ] Q-2: Limitar getPagamentos a 200
- [ ] Q-3: Filtrar renovacoes
